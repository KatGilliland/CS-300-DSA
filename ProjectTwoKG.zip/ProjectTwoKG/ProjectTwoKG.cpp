// Name: Kat Gilliland - Class: CS-300-DSA 

#include <iostream>  // Providing input and output functionality KG
#include <fstream>  // Allowing ability to create, write, and read files KG
#include <algorithm> // Necessary for sort feature KG
#include <vector> // Allowing for use of vector data structure KG
#include <string> // Allowing for use of strings KG

using namespace std; // Allowing use of standard library KG

struct Course { // Creating course structure KG
    string courseNumber; // Instance of course structure KG
    string name; // Instance of course structure KG 
    vector<string> prerequisites; // Instance of course structure KG 
};

/* Giving token function the ability to take input string and delimiter used for splitting string KG */
vector<string> token(const string& s, const string& del = ",") { 
    vector<string> tokens; // Initializing vector of strings to store/save tokens KG 
    size_t begin = 0, end = s.find(del); // Initializing beginning and end for substring extraction KG 
    while (end != string::npos) { // While statement for while end of string not found KG 
        tokens.push_back(s.substr(begin, end - begin)); // Extracting substring into tokens vector KG
        begin = end + del.size(); // Updating begin position to position after current delimiter KG
        end = s.find(del, begin); // Searching for next occurrence of delimiter after updated begin position KG 
      }
      tokens.push_back(s.substr(begin, end - begin)); // Pushing last token into tokens vector KG
      return tokens; // Returning vector/tokens KG
}

vector<Course> loadCourses() { // Reading in text file KG
    fstream fin("abcuCourses.txt", ios::in); // Opening file for reading KG
    vector<Course> courses; // Initializing empty vector of course objects to store data read from file KG
    string line; // Storing each line in a string KG

    while (getline(fin, line)) { // Looping through and reading each line KG 
        if (line == "-1") break; // Terminating loop if line equal -1 KG

            Course course; // Creating a Course object KG
            vector<string> courseInformation = token(line, ","); // Tokenizing lines for course info KG

            course.courseNumber = courseInformation[0]; // Assigning to a value in tokenized course info KG
            course.name = courseInformation[1]; // Assigning to a value in tokenized course info KG

            /*Adding any remaining fields(values outside of 0 and 1) to prerequisites vector KG */
            for (int i = 2; i < courseInformation.size(); ++i) { 
                course.prerequisites.push_back(courseInformation[i]);
            }
            courses.push_back(course);
        }
        fin.close(); // Closing file KG
        return courses; // Returning vector of Course objects KG
    }

    /* Printing course information(printCourseList and searchCourse use this function) KG */
    void printCourse(Course course) { 
        /* Getting info from the Course object KG*/
        string courseNumber = course.courseNumber;
        string name = course.name;

        /* Outputting course information KG */
        vector<string> prerequisites = course.prerequisites;
        cout << "Course Number: " << courseNumber << endl;
        cout << "Course Name: " << name << endl;
        cout << "Prerequisites: ";

        for (int i = 0; i < prerequisites.size(); ++i) { // For each prerequisite in the vector KG
            cout << prerequisites[i] << " "; // Output prerequisite KG
        }

       cout << endl; // Adds space between the output courses for better readability KG
       cout << endl; // Adds space between the output courses for better readability KG
    }

    void printCourseList(vector<Course>& courses) { // Printing course list KG
        sort(courses.begin(), courses.end(), // Using sort algorithm to sort through courses vector KG
            /* Comparing two course objects by their course number KG */
            [](const Course& a, const Course& b) { 
            return a.courseNumber < b.courseNumber; // Returning course objects in alphanumeric order KG
    }
        ); 
        for (const auto& course : courses) { // For the sorted courses in the vector KG 
            printCourse(course); // Output course information using printCourse function KG 
        }
    }

        /* start of another working section, don't mess with!*/
    void searchCourse(const vector<Course>& courses) { // Searching for course KG
        string courseNumber; // Initializing courseNumber string to store input KG
        cout << endl; // Adding space to improve output readability KG
        cout << "Please enter course number: " << endl; // Prompting user to enter course number KG
        cout << endl; // Adding space to improve output readability KG
        cout << "*Hint: Course numbers are case sensitive*" << endl; // Adding to make program more clear for user KG
        cin >> courseNumber; // Getting course number from user KG

        bool exist = false; // Setting bool exist to false KG

        for (const auto& course : courses) { // For each Course object in the courses vector KG
            /* If searched course number exists KG */
            if (course.courseNumber == courseNumber) { 
                exist = true; 
                cout << endl; // Adding to improve output readability KG
                printCourse(course); // Output course information KG
                break;
            }
        }
        if (!exist) { // If course number/course does not exist KG
            cout << endl; // Adding to improve output readability KG
            cout << "Could not find course with given course number. Please try again!"; // Letting user know course number/course cannot be found KG
        }
    }
      
    int main() // Starting program execution KG
    {
        vector<Course> courses; 

        cout << "Welcome to the course planner!\n"; // Output welcoming user to program menu
        cout << endl;
        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course" << endl;
        cout << "4. Exit" << endl;
        cout << endl;
        cout << "*Hint: Data structure must be loaded prior to accessing course information*" << endl; // Adding to make program more clear for user KG

        int choice; // Creating choice as an integer type variable to allow user to enter numerical values for menu selections KG
        do { // Do statement to loop menu until condition is satisfied KG
            cout << endl; // Adding space to improve output readability KG
            cout << "What would you like to do? ";
            cin >> choice; // Getting user input KG

            switch (choice) { // Switch statement for different menu options/possible user selections KG
            case 1:
                courses = loadCourses(); // Loading data structure KG
                cout << endl; // Adding space to improve output readability KG
                cout << "Data structure loaded successfully!" << endl; // Confirming data structure was loaded successfully KG
                break;
            case 2:
                cout << endl; // Adding space to improve output readability KG
                cout << "Here is a sample schedule: " << endl;
                cout << endl; // Adding space to improve output readability KG
                printCourseList(courses); // Printing course list KG
                break;
            case 3:
                searchCourse(courses); // Searching course list KG
                break;
            case 4:
                cout << "Thank you for using the course planner!" << endl; // Exiting program KG
                break;
            default: // Setting default case for if user enters invalid input KG
                cout << choice + " is not a valid option." << endl;
            }
        } while (choice != 4); // While user input is not equal to 4 (exit), continue running program KG
    
    return 0;
    }
    
    
    
    